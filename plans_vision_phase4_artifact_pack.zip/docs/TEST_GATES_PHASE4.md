# TEST_GATES_PHASE4 — Mandatory gates for Ingestion and Artifact

Gate 1 Ingest produces artifact
- Start ingest on a project with master PDF uploaded
- Status completes
- artifact_id returned and downloadable

Gate 2 Cache hit no vision calls
- Run ingest twice with no changes
- Second run returns cache hit
- Ensure no calls to vision pipelines occur

Gate 3 Fingerprint change invalidates
- Upload a new master PDF with different fingerprint
- Ingest creates a new revision and artifact
- old artifact remains accessible but not latest

Gate 4 Query after ingest uses stored data only
- After ingest, query endpoint returns results without calling models

Gate 5 Render after ingest uses stored data only
- After ingest, render annotated PDF works without calling models

Gate 6 Artifact download contains required sections
- Download includes pdf_master, mapping, guide, extraction, index, stats, trace

Gate 7 Deterministic artifact download
- Repeated downloads for same artifact are identical

Gate 8 Tenant isolation
- Artifact endpoints do not allow cross tenant access
