# WORK_QUEUE — Phase 4 Ingestion and Artifact

Allowed autonomous tasks for Phase 4.

Stop and ask if:
- any new recognition logic is introduced
- any query or render path adds model calls
- revision diffing is attempted

Tasks
1 Implement revision and artifact DB models
2 Implement v4 ingest job orchestration
3 Implement cache hit behavior
4 Implement artifact download and metadata endpoints
5 Add test gates Phase 4
6 Update docs/PROJECT_STATUS.md for Phase 4 start and lock
