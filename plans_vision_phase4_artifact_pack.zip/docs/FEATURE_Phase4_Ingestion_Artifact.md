# Feature Phase 4 — Project Ingestion and Artifact (One-shot Vision)

Status: READY TO IMPLEMENT

Phase 4 makes the API economically viable at scale:
- Run vision-heavy work once per project revision
- Persist a complete Project Artifact
- Serve queries and renders without re-running vision

No recognition rules are hardcoded. Phase 4 orchestrates existing phases and stores outputs.

## Goal

Given a master PDF plan set, the API should:
1 ingest and version the project
2 run the pipeline once (mapping, guide, extract, index)
3 produce a single artifact payload that supports later queries and renders with zero vision calls

## Definitions

- Revision: a versioned set of documents identified by fingerprints
- Artifact: the persisted, versioned output bundle for a revision
- Fresh: artifact exists and matches current revision fingerprints
- Stale: artifact missing or fingerprints changed

## In Scope

- Ingestion job endpoint (async)
- Revision and artifact versioning
- Cache policy: do not re-run vision if artifact is fresh
- Invalidate and re-ingest when PDFs change
- Export artifact as JSON downloadable
- Endpoints to retrieve artifact metadata and status

## Out of Scope

- Comparing revisions (diff) optional later
- Viewer UI
- Pricing and billing implementation
- Non plan documents semantics (devis/addenda) handled by Foto-Gestion

## Preconditions

- v1 guide endpoints exist and are locked
- v2 extract and query endpoints exist and are locked
- v3 mapping and render endpoints exist and are locked
- PDF masters can be uploaded and fingerprinted

## Core Principle

A project is analyzed once per revision. After that:
- query must be zero model calls
- render must be zero model calls
- the artifact is the source of truth for those operations

## Pipeline for Ingestion Job

For a project revision:
1 Upload and fingerprint PDF master
2 Build mapping for master PDF
3 Run v1 analyze guide on derived PNG pages
4 Run v2 extract to build objects and index
5 Persist outputs as an Artifact with version IDs and trace

## Artifact Contents minimum

- artifact_id, revision_id, created_at
- pdf_master: pdf_id, fingerprint, page_count
- mapping: mapping_version_id, per-page metadata
- guide: guide_version_id, stable guide summary, confidence report
- extraction: extraction_run_id, page types, objects summary counts
- index: index_version_id, deterministic keys summary
- stats: total_pages, objects_count_by_type, rejected_rules_count
- trace: schema versions for v1, v2, v3

Note: Full object geometry may be stored separately for size, but must be retrievable.

## Definition of Done

- Phase 4 endpoints implemented and documented
- TEST_GATES_PHASE4 all pass
- Ingesting a project produces an artifact
- Re-running ingest without changes is a no-op cache hit and does not call vision
- Any query after ingestion uses only stored artifact data
- Any render after ingestion uses only stored artifact data
