# PHASE4_DECISIONS — Locked decisions for artifact architecture

## No hardcoded recognition
Phase 4 does not introduce recognition rules.
It orchestrates existing v1 v2 v3 and stores results.

## Cache policy
- If current revision fingerprints match latest artifact revision, ingestion returns cache hit
- No vision calls on cache hit

## Revision identity
- Revision is defined by the set of pdf fingerprints used at minimum the master PDF

## Storage model
- Store artifact metadata in DB
- Store large payloads as separate blob files if needed
- Always provide a download endpoint to retrieve the full artifact JSON

## Query and render behavior
- After ingestion, query and render must be able to run from stored data only
- They must not require re-running vision

## Force mode
- force true allows re-ingestion even if cache hit
- force must be explicit

## Versioning
- schema_version for Phase 4 is 4.0
- v1 v2 v3 remain unchanged

## Security
- artifact retrieval is tenant scoped
- never expose raw pdf content unless explicitly requested
