# API_CONTRACT — Phase 4 Ingestion and Artifact (v4)

All responses include schema_version.

Base path: /v4
Auth: X-API-Key required

## Endpoints

### 1 Start ingestion async
POST /v4/projects/{project_id}/ingest

Request
```json
{
  "schema_version": "4.0",
  "pdf_master_id": "uuid",
  "mode": "architecture_only",
  "force": false
}
```

Response 202
```json
{
  "schema_version": "4.0",
  "project_id": "uuid",
  "revision_id": "uuid",
  "ingest_job_id": "uuid",
  "status": "processing",
  "cache": "miss"
}
```

Cache hit response 200
```json
{
  "schema_version": "4.0",
  "project_id": "uuid",
  "revision_id": "uuid",
  "status": "completed",
  "cache": "hit",
  "artifact_id": "uuid"
}
```

Errors
- 409 PDF_MASTER_REQUIRED
- 404 PROJECT_NOT_FOUND
- 409 EXTRACT_ALREADY_RUNNING

### 2 Ingest status
GET /v4/projects/{project_id}/ingest/{ingest_job_id}/status

Response 200
```json
{
  "schema_version": "4.0",
  "project_id": "uuid",
  "revision_id": "uuid",
  "ingest_job_id": "uuid",
  "overall_status": "pending|running|completed|failed",
  "current_step": "mapping|guide|extract|index|artifact|null",
  "steps": [
    { "name": "mapping", "status": "pending|running|completed|failed", "error": null }
  ],
  "artifact_id": "uuid|null",
  "cache": "miss|hit",
  "updated_at": "ISO8601"
}
```

### 3 Get latest artifact metadata
GET /v4/projects/{project_id}/artifact

Response 200
```json
{
  "schema_version": "4.0",
  "project_id": "uuid",
  "artifact_id": "uuid",
  "revision_id": "uuid",
  "pdf_master": { "pdf_id": "uuid", "fingerprint": "sha256", "page_count": 42 },
  "mapping_version_id": "uuid",
  "guide_version_id": "uuid",
  "extraction_run_id": "uuid",
  "index_version_id": "uuid",
  "created_at": "ISO8601",
  "status": "ready"
}
```

### 4 Download artifact JSON
GET /v4/projects/{project_id}/artifact/{artifact_id}/download

Response 200 Content-Type application/json
```json
{
  "schema_version": "4.0",
  "artifact_id": "uuid",
  "revision_id": "uuid",
  "pdf_master": { },
  "mapping": { },
  "guide": { },
  "extraction": { },
  "index": { },
  "stats": { },
  "trace": { }
}
```

### 5 Invalidate artifact optional
POST /v4/projects/{project_id}/artifact/invalidate

Response 200
```json
{
  "schema_version": "4.0",
  "project_id": "uuid",
  "status": "invalidated"
}
```

## Standard error format
```json
{
  "schema_version": "4.0",
  "error_code": "STRING",
  "message": "Human readable message",
  "recoverable": true
}
```
