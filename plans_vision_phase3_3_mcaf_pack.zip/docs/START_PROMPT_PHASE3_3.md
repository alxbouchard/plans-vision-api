# START_PROMPT_PHASE3_3.md

Read AGENTS.md and apply rules strictly.

Then read:
- docs/PROJECT_STATUS.md
- docs/WORK_QUEUE_PHASE3_3.md
- docs/FEATURE_Phase3_3_SpatialRoomLabeling.md
- docs/TEST_GATES_PHASE3_3.md
- docs/DECISIONS_Phase3_3.md

After reading, respond with one sentence:
- current phase
- what is completed
- immediate priority

Then wait.

When approved to implement:
- Work ticket by ticket in WORK_QUEUE_PHASE3_3.md order
- After each ticket: run targeted tests, then commit
- Do not change public API schemas unless explicitly asked
